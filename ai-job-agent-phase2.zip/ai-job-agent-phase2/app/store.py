import json
from pathlib import Path
DATA=Path("data"); DATA.mkdir(exist_ok=True)

def load(name, default):
    p=DATA/name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default

def save(name, value):
    (DATA/name).write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")

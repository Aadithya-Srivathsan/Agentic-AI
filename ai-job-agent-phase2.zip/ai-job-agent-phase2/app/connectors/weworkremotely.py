import feedparser
def fetch():
    # RSS discovery connector; applications remain user-approved.
    feed=feedparser.parse("https://weworkremotely.com/remote-jobs.rss")
    out=[]
    for e in feed.entries:
        title=e.get("title","")
        company=""
        role=title
        if ":" in title:
            company,role=[x.strip() for x in title.split(":",1)]
        out.append({
          "external_id":e.get("id",e.get("link","")),
          "title":role,
          "company":company,
          "location":"Remote",
          "source":"WeWorkRemotely",
          "url":e.get("link",""),
          "description":e.get("summary","")
        })
    return out

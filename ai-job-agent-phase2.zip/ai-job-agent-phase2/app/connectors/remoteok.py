import httpx
def fetch():
    # Public Remote OK JSON feed. Respect source terms and identify your app in production.
    url="https://remoteok.com/api"
    headers={"User-Agent":"AIJobAgent/0.2 (personal job discovery)"}
    r=httpx.get(url,headers=headers,timeout=20); r.raise_for_status()
    rows=r.json()
    out=[]
    for x in rows[1:]:
        if not isinstance(x,dict): continue
        out.append({
          "external_id":str(x.get("id","")),
          "title":x.get("position",""),
          "company":x.get("company",""),
          "location":x.get("location","Remote"),
          "source":"RemoteOK",
          "url":x.get("url",""),
          "description":x.get("description","")
        })
    return out

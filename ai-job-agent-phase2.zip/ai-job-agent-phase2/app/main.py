import os, uuid
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from dotenv import load_dotenv
load_dotenv()

from app.models import MasterProfile, Job, Approval, Application
from app.store import load, save
from app.services.ai import analyze
from app.services.resume import create_docx
from app.connectors.remoteok import fetch as remoteok_fetch
from app.connectors.weworkremotely import fetch as wwr_fetch

app=FastAPI(title="AI Job Agent Phase 2",version="0.2.0")

def profile():
    x=load("profile.json",None)
    if not x: raise HTTPException(400,"Create profile first")
    return MasterProfile(**x)

def job(job_id):
    for x in load("jobs.json",[]):
        if x["id"]==job_id:return Job(**x)
    raise HTTPException(404,"Job not found")

@app.get("/")
def root(): return {"status":"running","phase":2,"docs":"/docs"}

@app.put("/profile")
def set_profile(p:MasterProfile):
    save("profile.json",p.model_dump()); return {"saved":True}

@app.get("/profile")
def get_profile(): return profile()

@app.post("/jobs")
def add_job(j:Job):
    j.id=str(uuid.uuid4()); jobs=load("jobs.json",[]); jobs.append(j.model_dump()); save("jobs.json",jobs); return j

@app.get("/jobs")
def jobs(): return load("jobs.json",[])

@app.post("/discover")
def discover():
    found=[]
    if os.getenv("REMOTEOK_ENABLED","true").lower()=="true":
        try: found += remoteok_fetch()
        except Exception: pass
    if os.getenv("WEWORKREMOTELY_ENABLED","true").lower()=="true":
        try: found += wwr_fetch()
        except Exception: pass
    jobs=load("jobs.json",[])
    existing={(x.get("source"),x.get("external_id")) for x in jobs}
    added=0
    for x in found:
        key=(x["source"],x["external_id"])
        if key in existing: continue
        x["id"]=str(uuid.uuid4()); x["status"]="NEW"; jobs.append(x); existing.add(key); added+=1
    save("jobs.json",jobs)
    return {"discovered":len(found),"added":added,"total":len(jobs)}

@app.post("/jobs/{job_id}/analyze")
def analyze_job(job_id:str):
    return analyze(profile(),job(job_id))

@app.post("/jobs/{job_id}/prepare")
def prepare(job_id:str):
    p=profile(); j=job(job_id); result=analyze(p,j)
    path=create_docx(p,j,result)
    approvals=load("approvals.json",[])
    a=Approval(id=str(uuid.uuid4()),job_id=j.id,status="PENDING",resume_path=path,
               match_score=result.score,notes=result.risks)
    approvals.append(a.model_dump()); save("approvals.json",approvals)
    return {"approval":a,"analysis":result}

@app.get("/approvals")
def approvals(): return load("approvals.json",[])

@app.post("/approvals/{approval_id}/approve")
def approve(approval_id:str):
    approvals=load("approvals.json",[])
    target=None
    for a in approvals:
        if a["id"]==approval_id:
            a["status"]="APPROVED"; target=a; break
    if not target: raise HTTPException(404,"Approval not found")
    save("approvals.json",approvals)
    apps=load("applications.json",[])
    ap=Application(id=str(uuid.uuid4()),job_id=target["job_id"],approval_id=approval_id)
    apps.append(ap.model_dump()); save("applications.json",apps)
    return ap

@app.get("/applications")
def applications(): return load("applications.json",[])

@app.post("/applications/{application_id}/mark-submitted")
def mark_submitted(application_id:str):
    apps=load("applications.json",[]); target=None
    for a in apps:
        if a["id"]==application_id:
            a["status"]="SUBMITTED"
            a["submitted_at"]=datetime.now(timezone.utc).isoformat()
            target=a; break
    if not target: raise HTTPException(404,"Application not found")
    save("applications.json",apps); return target

@app.get("/approvals/{approval_id}/resume")
def resume_file(approval_id:str):
    for a in load("approvals.json",[]):
        if a["id"]==approval_id:
            return FileResponse(a["resume_path"])
    raise HTTPException(404,"Approval not found")

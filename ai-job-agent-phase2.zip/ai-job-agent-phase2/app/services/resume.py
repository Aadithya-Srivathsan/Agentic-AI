from pathlib import Path
from docx import Document
from app.models import MasterProfile, Job, MatchResult
from app.services.ai import tailored_summary

def create_docx(profile: MasterProfile, job: Job, result: MatchResult):
    d=Document()
    d.add_heading(profile.name,0)
    contact=" | ".join(x for x in [profile.email,profile.phone] if x)
    if contact: d.add_paragraph(contact)
    d.add_paragraph(tailored_summary(profile,job,result))

    d.add_heading("Technical Skills",1)
    matched={x.lower() for x in result.matched_requirements}
    skills=sorted(profile.skills,key=lambda x:(x.lower() not in matched,x.lower()))
    d.add_paragraph(" • ".join(skills))

    d.add_heading("Professional Experience",1)
    for e in profile.experience:
        d.add_heading(f"{e.role} — {e.company}",2)
        d.add_paragraph(f"{e.start} – {e.end}")
        # Preserve original facts. Reordering only.
        bullets=sorted(e.bullets,key=lambda b:-sum(k.lower() in b.lower() for k in result.matched_requirements))
        for b in bullets: d.add_paragraph(b,style="List Bullet")

    if profile.projects:
        d.add_heading("Projects",1)
        for p in profile.projects: d.add_paragraph(p,style="List Bullet")
    if profile.education:
        d.add_heading("Education",1)
        for x in profile.education: d.add_paragraph(x)
    if profile.certifications:
        d.add_heading("Certifications",1)
        for x in profile.certifications: d.add_paragraph(x)

    out=Path("generated"); out.mkdir(exist_ok=True)
    safe="".join(c if c.isalnum() or c in "-_" else "_" for c in f"{job.company}_{job.title}_{job.id}")
    path=out/f"{safe}.docx"; d.save(path)
    return str(path)

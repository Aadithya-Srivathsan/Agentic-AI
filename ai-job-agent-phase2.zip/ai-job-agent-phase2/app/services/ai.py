import os, json, re
from openai import OpenAI
from app.models import MasterProfile, Job, MatchResult

def _client():
    key=os.getenv("OPENAI_API_KEY","").strip()
    return OpenAI(api_key=key) if key else None

def analyze(profile: MasterProfile, job: Job) -> MatchResult:
    client=_client()
    if not client:
        return heuristic(profile, job)

    prompt = {
      "rule": "Use ONLY facts in PROFILE. Never infer or invent experience. Missing requirements must stay missing.",
      "profile": profile.model_dump(),
      "job": job.model_dump(),
      "output": {
        "score": "integer 0-100",
        "matched_requirements": ["strings"],
        "missing_requirements": ["strings"],
        "strengths": ["strings"],
        "risks": ["strings"],
        "decision": "APPLY or REVIEW or SKIP"
      }
    }
    r=client.chat.completions.create(
        model=os.getenv("OPENAI_MODEL","gpt-4.1-mini"),
        messages=[
          {"role":"system","content":"You are a conservative ATS/job-fit evaluator. Output JSON only."},
          {"role":"user","content":json.dumps(prompt)}
        ],
        response_format={"type":"json_object"},
        temperature=0
    )
    return MatchResult(**json.loads(r.choices[0].message.content))

def heuristic(profile, job):
    text=(job.title+" "+job.description).lower()
    skills=[s for s in profile.skills if s.lower() in text]
    detected=[x for x in ["aws","azure","gcp","linux","terraform","docker","kubernetes","jenkins","python","ansible","helm","prometheus","grafana"] if x in text]
    missing=[x for x in detected if x not in {s.lower() for s in profile.skills}]
    score=50 if not detected else round(100*len(skills)/max(1,len(detected)))
    return MatchResult(score=min(100,score),matched_requirements=skills,missing_requirements=missing,
        strengths=skills[:6],risks=[f"Missing: {x}" for x in missing],
        decision="APPLY" if score>=75 else "REVIEW")

def tailored_summary(profile: MasterProfile, job: Job, result: MatchResult) -> str:
    client=_client()
    if not client:
        focus=", ".join(result.matched_requirements[:6])
        return f"{profile.headline}. Relevant strengths for {job.title}: {focus}. {profile.summary}".strip()
    payload={"profile_summary":profile.summary,"headline":profile.headline,
             "matched":result.matched_requirements,"job_title":job.title,
             "instruction":"Rewrite a 3-4 sentence resume summary using only supplied facts. Do not add claims."}
    r=client.chat.completions.create(
        model=os.getenv("OPENAI_MODEL","gpt-4.1-mini"),
        messages=[{"role":"system","content":"Truthful ATS resume writer. Never invent facts."},
                  {"role":"user","content":json.dumps(payload)}],
        temperature=0.2
    )
    return r.choices[0].message.content.strip()

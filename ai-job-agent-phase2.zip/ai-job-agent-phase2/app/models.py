from pydantic import BaseModel, Field
from typing import List, Optional

class Experience(BaseModel):
    company: str
    role: str
    start: str
    end: str
    bullets: List[str] = []

class MasterProfile(BaseModel):
    name: str
    email: str = ""
    phone: str = ""
    headline: str = ""
    summary: str = ""
    skills: List[str] = []
    experience: List[Experience] = []
    education: List[str] = []
    certifications: List[str] = []
    projects: List[str] = []
    target_roles: List[str] = []
    preferred_locations: List[str] = []
    remote_ok: bool = True

class Job(BaseModel):
    id: Optional[str] = None
    external_id: str = ""
    title: str
    company: str
    location: str = ""
    source: str = "manual"
    url: str = ""
    description: str
    status: str = "NEW"

class MatchResult(BaseModel):
    score: int = Field(ge=0, le=100)
    matched_requirements: List[str] = []
    missing_requirements: List[str] = []
    strengths: List[str] = []
    risks: List[str] = []
    decision: str = "REVIEW"

class Approval(BaseModel):
    id: str
    job_id: str
    status: str = "PENDING"
    resume_path: str
    match_score: int
    notes: List[str] = []

class Application(BaseModel):
    id: str
    job_id: str
    approval_id: str
    status: str = "APPROVED_NOT_SUBMITTED"
    submitted_at: str = ""

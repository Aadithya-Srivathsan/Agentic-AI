# AI Job Agent — Phase 2

Phase 2 adds:
- OpenAI-powered JD analysis and match scoring
- Truth-constrained resume tailoring
- DOCX generation
- Approval queue
- Application tracker
- Public/permitted remote-job feed connectors
- Scheduled discovery endpoint
- Docker support

## Safety / portal boundary
This app does NOT bypass CAPTCHAs, anti-bot controls, authentication controls, or portal restrictions.
LinkedIn, Glassdoor and Naukri should be connected only through official/permitted APIs, feeds,
alerts, partner integrations, or a user-controlled approval workflow.

## Quick start
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Open: http://127.0.0.1:8000/docs

## Core flow
1. PUT /profile
2. POST /discover
3. GET /jobs
4. POST /jobs/{id}/analyze
5. POST /jobs/{id}/prepare
6. GET /approvals
7. POST /approvals/{id}/approve
8. POST /applications/{id}/mark-submitted

## 24/7 deployment
Containerize this app and run it on AWS ECS/Fargate or App Runner.
Trigger POST /discover on a schedule using EventBridge + Lambda/API destination.
Use PostgreSQL/RDS in production instead of JSON files.
